import os
print "UPDATING..."
os.system("cd")
os.system('cd /root/ && rm -fr hackers-tool-kit && git clone https://github.com/unkn0wnh4ckr/hackers-tool-kit && echo "[UPDATED]:  Restart Your Terminal"')